package net.stark.rodpull;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RodPull extends JavaPlugin implements Listener {

    private final Map<UUID, BukkitTask> tasks = new HashMap<>();
    private final Map<UUID, Long> noFallUntil = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        reloadConfig();
        s.sendMessage("§aRodPull reloaded.");
        return true;
    }

    @EventHandler
    public void onFish(PlayerFishEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPermission("rodpull.use")) return;

        PlayerFishEvent.State st = e.getState();
        Location target;

        if (st == PlayerFishEvent.State.IN_GROUND) {
            FishHook hook = e.getHook();
            target = hook.getLocation().clone();
        } else if (st == PlayerFishEvent.State.CAUGHT_ENTITY && getConfig().getBoolean("pull-to-entities", true)) {
            Entity caught = e.getCaught();
            if (caught == null) return;
            target = caught.getLocation().clone();
        } else {
            return;
        }

        if (!target.getWorld().equals(p.getWorld())) return;
        double dist = target.distance(p.getLocation());
        if (dist < getConfig().getDouble("min-distance", 3.0)) return;
        if (dist > getConfig().getDouble("max-distance", 40.0)) return;

        startPull(p, target.add(0, 0.3, 0));
    }

    private void startPull(Player p, Location target) {
        BukkitTask old = tasks.remove(p.getUniqueId());
        if (old != null) old.cancel();

        final double speed = getConfig().getDouble("speed", 1.4);
        final int maxTicks = getConfig().getInt("max-ticks", 40);
        final boolean noFall = getConfig().getBoolean("no-fall-damage", true);

        if (noFall) noFallUntil.put(p.getUniqueId(), System.currentTimeMillis() + maxTicks * 50L + 3000L);

        BukkitTask task = new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead() || t++ > maxTicks) {
                    finish();
                    return;
                }
                Vector diff = target.toVector().subtract(p.getLocation().toVector());
                double d = diff.length();
                if (d < 1.5) {
                    p.setVelocity(diff.multiply(0.2));
                    finish();
                    return;
                }
                double v = Math.min(speed, d * 0.5 + 0.3);
                p.setVelocity(diff.normalize().multiply(v));
                p.setFallDistance(0);
            }

            private void finish() {
                p.setFallDistance(0);
                tasks.remove(p.getUniqueId());
                cancel();
            }
        }.runTaskTimer(this, 0L, 1L);

        tasks.put(p.getUniqueId(), task);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        Long until = noFallUntil.get(p.getUniqueId());
        if (until == null) return;
        if (System.currentTimeMillis() <= until) e.setCancelled(true);
        else noFallUntil.remove(p.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        BukkitTask t = tasks.remove(e.getPlayer().getUniqueId());
        if (t != null) t.cancel();
        noFallUntil.remove(e.getPlayer().getUniqueId());
    }
}
